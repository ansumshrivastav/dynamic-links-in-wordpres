<?php
/*
Plugin Name: Dynamic Link Plugin
Plugin URI: https://www.ansum.com.np/
Description: Adds a dynamic link form in the backend and displays the link on the front end.
Author: Ansum
Author URI: https://www.ansum.com.np/
*/


// Enqueue necessary scripts and styles
function enqueue_dynamic_link_scripts() {
    wp_enqueue_script('dynamic-link-script', plugins_url('/js/dynamic-link.js', __FILE__), array('jquery'), '1.0', true);
}
add_action('wp_enqueue_scripts', 'enqueue_dynamic_link_scripts');

// Register a custom shortcode to display the link on the front end
function dynamic_link_shortcode() {
    $link = get_option('dynamic_link', ''); // Retrieve the link from the database
    return '<div id="link-container">' . $link . '</div>';
}
add_shortcode('dynamic_link', 'dynamic_link_shortcode');

// Create the admin page
function dynamic_link_admin_page() {
    add_submenu_page(
        'options-general.php',
        'Dynamic Link Settings',
        'Dynamic Link',
        'manage_options',
        'dynamic-link-settings',
        'dynamic_link_settings_page'
    );
}
add_action('admin_menu', 'dynamic_link_admin_page');

// Create the settings page in the admin dashboard
function dynamic_link_settings_page() {
    if (!current_user_can('manage_options')) {
        wp_die('You do not have sufficient permissions to access this page.');
    }

    if (isset($_POST['dynamic_link'])) {
        $link = sanitize_text_field($_POST['dynamic_link']);
        update_option('dynamic_link', $link); // Save the link to the database
    }

    $link = get_option('dynamic_link', '');
    ?>
    <div class="wrap">
        <h1>Dynamic Link Settings</h1>
        <form method="post" action="">
            <label for="dynamic-link">Link:</label>
            <input type="text" name="dynamic_link" id="dynamic-link" value="<?php echo esc_attr($link); ?>" required>
            <p class="description">Enter the link to display on the front end.</p>
            <?php submit_button('Save Link'); ?>
        </form>
    </div>
    <?php
}
