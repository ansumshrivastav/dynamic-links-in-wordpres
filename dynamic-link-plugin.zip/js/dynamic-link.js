jQuery(document).ready(function($) {
    // Get the link value from the backend
    var link = $('#link-container').text();

    // Display the link on the front end with class names
    $('#link-container').html('<div class="link-container"><input class="actual-link" type="text" value="' + link + '" readonly></div><button class="copy-button">Copy Link</button><div class="inline-alert"></div>');

    // Copy link to clipboard
    $('.copy-button').click(function() {
        var copyText = $('.actual-link')[0];
        copyText.select();
        document.execCommand('copy');
        
        // Show inline alert
        $('.inline-alert').text('Link copied to clipboard!');
        $('.inline-alert').addClass('alert-success');
        
        // Remove inline alert after 3 seconds
        setTimeout(function() {
            $('.inline-alert').text('');
            $('.inline-alert').removeClass('alert-success');
        }, 3000);
    });
});
